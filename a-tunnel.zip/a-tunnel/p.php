<?php
$source = 'sitemap1.xml';
$minified = 'sitemap.min.xml';

$xml = file_get_contents($source);
$min = preg_replace('/>\s+</', '><', $xml); // hapus spasi & newline
$min = trim($min);

file_put_contents($minified, $min);
echo "Sitemap berhasil diminify ke: $minified\n";
?>